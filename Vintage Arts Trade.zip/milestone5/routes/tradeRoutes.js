const express = require('express');
const router = express.Router();
const controller = require('../controllers/tradeController');
const { isLoggedIn, isHost } = require('../middlewares/auth');
const { validateId, validateArt, validateResult } = require('../middlewares/validator'); 

//GET /stories: send all stories to the user
router.get('/', controller.index);

//GET /stories/new: send html form for creating a new story
router.get('/new', isLoggedIn, controller.new);

//POST /stories: create a new story
router.post('/', isLoggedIn, validateArt, validateResult, controller.create);

//GET /stories/:id: send details of story identified by id
router.get('/:id', validateId, controller.show);

//GET /stories/:id: send html form for editing an existing story
router.get('/:id/edit', validateId, isLoggedIn, isHost, controller.edit);

//PUT /stories/:id: update the story identified by id
router.put('/:id', validateId, isLoggedIn, isHost, validateArt, validateResult, controller.update);

//DELETE /stories/:id: delete the story identified by id
router.delete('/:id', validateId, isLoggedIn, isHost, controller.delete);

router.post('/:id/interested', validateId, isLoggedIn, controller.interested);

router.post('/:id/notinterested', validateId, isLoggedIn, controller.notinterested);

router.post('/:id/tradeitem', validateId, isLoggedIn, controller.tradeitem);

router.post('/:id/tradeoffered',validateId, isLoggedIn, controller.tradeoffered);

router.post('/:id/offercancel', validateId, isLoggedIn, controller.offercancel);

router.post('/:id/manageOffer', validateId, isLoggedIn, controller.manageOffer);

router.post('/:id/acceptOffer', validateId, isLoggedIn, controller.acceptOffer);

router.post('/:id/rejectOffer', validateId, isLoggedIn, controller.rejectOffer);

module.exports = router;  