const { DateTime } = require('luxon');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const vintageSchema = new Schema({
    artstyle: {type: String, required: [true, 'ArtStyle is required']},
    name: {type: String, required: [true, 'Name is required']},    
    createdon: {type: String, required: [true, 'Created on year is required']},
    details: {type: String, required: [true, 'Detail is required'], 
            minLength: [10, 'The detail should have at least 10 characters']},
    status: {type: String, required: [true]},   
    artist: {type: String, required: [true, 'Artist is required']},   
    owner: {type: Schema.Types.ObjectId, ref: 'User'},
    image: {type: String, required: [true, 'Image is required']},   
    createAt:{type: String},    
},
{timestamps: true}
);

//collection name is vintage in database
module.exports = mongoose.model('Vintage', vintageSchema);
